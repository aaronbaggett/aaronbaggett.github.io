try(dev.off(),silent=TRUE)
plot.new()
plot(as.dendrogram(hc))