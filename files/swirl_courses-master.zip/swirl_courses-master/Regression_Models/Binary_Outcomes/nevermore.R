boxplot(ravenScore ~ ravenWin, ravenData, col=0x96, lwd=3, horizontal=TRUE, 
        col.lab="purple", col.main="purple", xlab="Ravens' Score", 
        main="Ravens' Wins and Losses vs Score")